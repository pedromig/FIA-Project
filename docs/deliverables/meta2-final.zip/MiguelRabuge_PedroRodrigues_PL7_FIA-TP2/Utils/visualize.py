#!/usr/bin/python3

import matplotlib.pyplot as plt
import pandas as pd
import getpass
import numpy as np
import subprocess
import sys
import os

MVA = 300

def moving_average(x, w):
   return np.convolve(x, np.ones(w), 'valid') / w

def plot_real_time(x, avg_red, avg_blue, best_red, best_blue):
    plt.plot(x, best_red, color='red', linestyle='solid')
    plt.plot(x, best_blue, color='blue', linestyle='solid')
    plt.plot(x, avg_red, color='lightcoral', linestyle='solid')
    plt.plot(x, avg_blue, color='cornflowerblue', linestyle='solid')
    plt.xlabel("Generation")
    plt.ylabel("Fitness")
    plt.legend(['Best Red', "Best Blue", 'Average Red', "Average Blue"])


def get_remote_file(user, password, host, file):
    return_code = subprocess.call(["sshpass", "-p", password, "scp", "-r", user + "@" +
                                   host + ":~/" + file, os.getcwd()])
    if return_code != 0:
        exit("Error: Failed to retrieve remote file.")
    return pd.read_csv(os.getcwd() + "/" + file.split("/")[-1])


if __name__ == "__main__":

    if len(sys.argv) != 3:
        exit("Usage: python3 " + sys.argv[0] + " {HOSTNAME} {FILE}")

    username = "mike"
    password = "123mike123"
    hostname = sys.argv[1]
    plt.figure()

    # Get csv
    df = get_remote_file(username, password, hostname, sys.argv[2])

    # Plot previous values
    x = df['Generation'].tolist()
    avg_red = df['PopAvgRed'].tolist()
    avg_blue = df['PopAvgBlue'].tolist()
    best_red = df['BestOverallRed'].tolist()
    best_blue = df['BestOverallBlue'].tolist()

    plot_real_time(moving_average(x, MVA),
                    moving_average(avg_red, MVA),
                    moving_average(avg_blue, MVA),
                    moving_average(best_red, MVA),
                    moving_average(best_blue, MVA))

    # Future plotting form x in x time
    while(True):
        new_df = get_remote_file(username, password, hostname, sys.argv[2])
        new_x = new_df['Generation'].tolist()[-1]
        if (new_x != x[-1]):
            print(f"Current Generation: {new_x}")
            df = new_df
            new_avg_red = df['PopAvgRed'].tolist()[-1]
            new_avg_blue = df['PopAvgBlue'].tolist()[-1]
            new_best_red = df['BestOverallRed'].tolist()[-1]
            new_best_blue = df['BestOverallBlue'].tolist()[-1]
            x.append(new_x)
            avg_red.append(new_avg_red)
            avg_blue.append(new_avg_blue)
            best_red.append(new_best_red)
            best_blue.append(new_best_blue)
            plot_real_time(moving_average(x, MVA),
                           moving_average(avg_red, MVA),
                           moving_average(avg_blue, MVA),
                           moving_average(best_red, MVA),
                           moving_average(best_blue, MVA))
        plt.pause(10)
